package P1Tarller1SantosFernanda;

public class P1Tarller1SantosFernanda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
		abstract class animal{
			String sonido;
		}
		class Leopardo extends animal{
			private final String sonido
			public Leopardo();

	}
}
